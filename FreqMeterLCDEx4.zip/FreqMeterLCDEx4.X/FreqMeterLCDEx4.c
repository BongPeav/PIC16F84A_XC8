#include <stdio.h>
#include <xc.h>

#define _XTAL_FREQ 4000000UL

#include "LCD4Bits.h"

void tmr0Init(void){
    PORTA=0;
    TRISA4=1;
    T0CS=1;
    T0SE=0;
    PSA=1;
    OPTION_REGbits.PS=0;
    T0IE=1;
    GIE=1;
    T0IF=0;
}

long TMR0H=0;

void interrupt T0_ISR(void){
    if(T0IF){
        TMR0H+=1;
        T0IF=0;
    }
}

int main(void){
    unsigned char freq[10];
    uint32_t temp=0;
    PORTB=0;
    TRISB=0;
    lcdInit();
    tmr0Init();
    lcdXY(4,1);
    lcdString("PIC16F84A");
    lcdXY(1,2);
    lcdString("Frequency Meter");
    __delay_ms(1000);
    lcdCommand(CLEAR_SCREEN);
    __delay_ms(5);
    lcdXY(4,1);
    lcdString("Frequency:");
    TMR0H=0;
    TMR0=0;
    while(1){
        __delay_ms(1000);
        temp=(TMR0H<<8)+TMR0;
        lcdXY(6,2);
        sprintf(freq,"%uHz ",temp);
        lcdString(freq);
        TMR0H=0;
        TMR0=0;
    }
    return 0;
}