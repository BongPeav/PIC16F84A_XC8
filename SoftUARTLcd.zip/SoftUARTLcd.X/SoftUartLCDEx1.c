/*
 Software UART LCD Example 1
 */
#include <xc.h>
#include "LCD4Bits.h"

// PIC16F84A Configuration Bit Settings

// CONFIG
#pragma config FOSC = XT        // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF       // Watchdog Timer (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (Power-up Timer is disabled)
#pragma config CP = OFF         // Code Protection bit (Code protection disabled)

#define _XTAL_FREQ  4000000
#define TX  RA0
#define RX  RA1

void sendChar(char data){
    TX=0;
    __delay_us(100);
    for(int i=0;i<8;i++){
        TX=data&(1<<0);
        data>>=1;
        __delay_us(75);
    }
    TX=1;
    __delay_us(100);
}

char myChar=0,temp=0;
void receiveChar(void){
    if(RX==0){
        __delay_us(100);
        for(char i=0;i<8;i++){
            __delay_us(60);
            if(RX==1) myChar|=(1<<i);
            else myChar&=~(1<<i);
        }
        __delay_us(100);
    }
}
void sendText(char *text){
    while(*text) sendChar(*text++);
}

void softUARTInit(void){
    PORTA=0x00;
    TRISA=0x02;
    PORTB=0;
    TRISB=0;
    TX=1;
}

void main(){
    uint8_t line=1,charNum=1;
    softUARTInit();
    lcdInit();
    sendText("PIC16F84A Software UART And Character LCD\r\n");
    lcdString("PIC16F84A 20x4 LCD");
    lcdXY(1,2);
    lcdString("Software Delay UART");
    lcdXY(1,3);
    lcdString("Programming Example");
    lcdXY(1,4);
    lcdString("MPLABX IDE And XC8");
    __delay_ms(2000);
    lcdClear();
    
    while(1){
        receiveChar();
        if(myChar!=0&&myChar!=0x08){
            sendChar(myChar);
            if(myChar=='0') { RA2^=1; sendText(" Toggle RA2.\r\n");}
            if(myChar=='1') { RA3^=1; sendText(" Toggle RA3.\r\n");}
            if(myChar==0x0D) {
                line+=1;
                lcdXY(1,line);
                charNum=1;
            }else{
                lcdData(myChar);
            }
            charNum+=1;
            if(charNum>20) {charNum=1; line+=1; lcdXY(charNum,line);}
            if(line>4){line=1;lcdXY(charNum,line);}
            myChar=0;
        }
    }
}