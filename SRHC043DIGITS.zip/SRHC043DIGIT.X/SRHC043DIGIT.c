
#include <xc.h>

// PIC16F84A Configuration Bit Settings
// CONFIG
#pragma config FOSC = XT        // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF        // Watchdog Timer (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (Power-up Timer is disabled)
#pragma config CP = OFF         // Code Protection bit (Code protection disabled)

#define _XTAL_FREQ  4000000UL
#define TRIGGER     RA3
#define ECHO        RA4

volatile uint8_t T0OV=0;
volatile uint16_t myCounter=0,myDisplayTime=0;

void interrupt T0_ISR(void){
    if(T0IF){
        T0OV+=1;
        myCounter++;
        myDisplayTime++;
        T0IF=0;
    }
}

uint16_t getDistance=0,temp=0;

void readDistance(void){
    TRIGGER=1;
    __delay_us(10);
    TRIGGER=0;
    __delay_us(30);
    while(ECHO==0){
        /*Waiting For High Pulse Response, Or Sensor Present*/
        temp++;
        __delay_us(10);
        if(temp>=20) break;
    }
    TMR0=0;
    T0OV=0;
    while(ECHO==1);
    temp=(T0OV<<8)+TMR0+20;
    getDistance=temp/58;

    if(getDistance>=433){
        getDistance=0;
    }

    temp=0;
    T0OV=0;
    TMR0=0;
}

int main(void){
    uint8_t data7[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
    PORTA=0;
    TRISA=0x10;

    PORTB=0;
    TRISB=0;
    T0CS=0;
    PSA=1;
    OPTION_REGbits.PS=0;
    T0IE=1;
    GIE=1;
    T0IF=0;

    
    TMR0=0;

    while(1){
        if(myCounter>=2000){
            readDistance();
            myCounter=0;
        }
        if(myDisplayTime>=60) myDisplayTime=0;
        switch(myDisplayTime){
            case 0:
                PORTA=0;
                PORTB=data7[getDistance/100];
                RA0=1;
                break;
            case 20:
                PORTA=0;
                PORTB=data7[(getDistance%100)/10];
                RA1=1;
                break;
            case 40:
                PORTA=0;
                PORTB=data7[getDistance%10];
                RA2=1;
                break;
        }
    }
    return 0;
}