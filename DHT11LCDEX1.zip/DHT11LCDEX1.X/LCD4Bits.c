
#include <xc.h>
#include "LCD4Bits.h"

void lcdCommand(uint8_t cmd){
    DATA8=cmd&0xF0;
    RS=0;
    EN=1;
    __delay_us(10);
    EN=0;
    __delay_us(10);

    DATA8=cmd<<4;
    RS=0;
    EN=1;
    __delay_us(10);
    EN=0;
    __delay_us(10);

    __delay_us(100);
}

void lcdData(uint8_t dat){
    DATA8=dat&0xF0;
    RS=1;
    EN=1;
    __delay_us(10);
    EN=0;
    __delay_us(10);

    DATA8=dat<<4;
    RS=1;
    EN=1;
    __delay_us(10);
    EN=0;
    __delay_us(10);

    __delay_us(100);
}

void lcdXY(uint8_t x,uint8_t y){
    uint8_t addr[]={0x80,0xC0};
    lcdCommand(addr[y-1]+x-1);
}

void lcdString(uint8_t *str){
    while(*str) lcdData(*str++);
}

void lcdInit(void){
    EN=0;
    __delay_us(100);
    lcdCommand(0x33);
    __delay_us(1);
    lcdCommand(0x32);
    __delay_us(1);
    lcdCommand(_4_BIT);
    __delay_us(100);
    lcdCommand(ON_CURSOR_OFF);
    __delay_us(1);
    lcdCommand(CLEAR_SCREEN);
    __delay_ms(10);
    lcdCommand(CURSOR_RIGHT);
}
