/*
 * PIC16F84A DHT11 Temperature and Humidity Sensor Interfacing
 * With HD44780 Character LCD
 * MPLABX IDE v1.51
 * XC8 v2.36
 */

#include <xc.h>
#include "LCD4Bits.h"

#define _XTAL_FREQ  4000000UL
#define DATA_PIN    RA4
#define DATA_DIR    TRISA4

uint8_t data[5];
void readDHT11(void){
    for(uint8_t i=0;i<5;i++) data[i]=0;  
    DATA_DIR=0;
    DATA_PIN=1;
    __delay_ms(10);
    DATA_PIN=0;
    __delay_ms(18);
    DATA_PIN=1;
    __delay_us(30);
    DATA_PIN=0;
    DATA_DIR=1;
    __delay_us(10);
    while(DATA_PIN==0);
    __delay_us(10);
    while(DATA_PIN==1);
    __delay_us(10);
   
    //Start of Transmission  
    for(uint8_t i=0;i<5;i++) {
        for(uint8_t j=0;j<8;j++){
        __delay_us(5);
        while(DATA_PIN==0);
        __delay_us(50);
        if(DATA_PIN==1) { data[i]|=(1<<7-j);}
    }
       __delay_us(10);
    }
    /*CRC Calculation - the last byte data[4] is check sum*/
    uint8_t crc = data[0]+data[1]+data[2]+data[3];
    if(crc!=data[4]) {for(uint8_t i=0;i<4;i++) data[i]=0; return;}
    __delay_us(10);
}
int main(void){
    PORTA=0;
    TRISA=0;
    
    PORTB=0;
    TRISB=0;
 
    lcdInit();
   
    lcdXY(1,1); lcdString("Humidity   : ");
    lcdXY(1,2); lcdString("Temperature: ");
    
    while(1){
         readDHT11();
        
         lcdXY(13,1);
        /*Humidity is below 90RH*/
        if(data[0]>=10) lcdData(48+(data[0]%100)/10);
        lcdData(48+(data[0]%10));
        lcdData('R');
        lcdData('H');
       
        /*Temperature is below 50 degree Celsius*/
        lcdXY(13,2);
        if(data[2]>=10) lcdData(48+data[2]/10);
        lcdData(48+(data[2]%10));
        lcdData(223);
        lcdData('C');
        __delay_ms(500);              
    }
    return 0;
}