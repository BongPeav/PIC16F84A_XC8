
/*
 for 9600 baud rate
 * 1/9600 = 104uS per bit
 * we can use 102.5uS per bit or above
 */

#include <xc.h>

// PIC16F84A Configuration Bit Settings

// CONFIG
#pragma config FOSC = XT        // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF       // Watchdog Timer (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (Power-up Timer is disabled)
#pragma config CP = OFF         // Code Protection bit (Code protection disabled)

#define _XTAL_FREQ  4000000
#define TX  RA0
#define RX  RA1

__EEPROM_DATA('H','E','L','L','O','S','I','R');
__EEPROM_DATA('P','I','C','1','6','F','8','4');
__EEPROM_DATA(' ','S','i','m','p','l','e',' ');
__EEPROM_DATA('U','A','R','T',' ','P','r','o');
__EEPROM_DATA('g','r','a','m','m','i','n','g');
__EEPROM_DATA(' ','W','i','t','h',' ','M','P');
__EEPROM_DATA('L','A','B','X',' ','I','D','E');
__EEPROM_DATA(' ','X','C','8',' ','C',' ','.');

void sendChar(char data){
    TX=0;
    __delay_us(100);
    for(int i=0;i<8;i++){
        TX=data&(1<<0);
        data>>=1;
        __delay_us(75);
    }
    TX=1;
    __delay_us(100);
}

char myChar=0,temp=0;
void receiveChar(void){
    if(RX==0){
        __delay_us(100);

        for(char i=0;i<8;i++){
            __delay_us(60);
            if(RX==1) myChar|=(1<<i);
            else myChar&=~(1<<i);
        }
        __delay_us(100);
    }
}
void sendText(char *text){
    while(*text) sendChar(*text++);
}

void softUARTInit(void){
    PORTA=0x00;
    TRISA=0x02;
    PORTB=0;
    TRISB=0;
    TX=1;
}

void main(){

    softUARTInit();
    sendText("PIC16F84A Software UART Read EEPROM Example 1\r\n");
    for(uint8_t i=0;i<8;i++) sendChar(EEPROM_READ(i));
    sendText("\r\n");
    for(uint8_t i=8;i<64;i++) sendChar(EEPROM_READ(i));
    while(1){
      
    }
}
