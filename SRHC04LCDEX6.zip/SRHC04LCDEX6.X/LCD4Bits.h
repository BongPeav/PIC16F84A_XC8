
#ifndef _XTAL_FREQ
#define _XTAL_FREQ 4000000UL
#endif

#define RS    RB0
#define EN    RB1
#define DATA8 PORTB

#define CLEAR_SCREEN  0x01
#define HOME          0x02
#define CURSOR_RIGHT  0x06
#define ON_CURSOR_OFF 0x0C
#define ON_NOT_BLINK  0x0E
#define ON_BLINK      0x0F
#define MOVE_LEFT     0x18
#define MOVE_RIGHT    0x1C
#define _4_BIT        0x28
#define _8_BIT        0x38

void lcdCommand(uint8_t cmd);
void lcdData(uint8_t dat);
void lcdXY(uint8_t x,uint8_t y);
void lcdString(uint8_t *str);
void lcdInit(void);
