
/*
 for 9600 baud rate
 * 1/9600 = 104uS per bit
 * we can use 102.5uS per bit or above
 */

#include <xc.h>

// PIC16F84A Configuration Bit Settings

// CONFIG
#pragma config FOSC = XT        // Oscillator Selection bits (XT oscillator)
#pragma config WDTE = OFF       // Watchdog Timer (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (Power-up Timer is disabled)
#pragma config CP = OFF         // Code Protection bit (Code protection disabled)

#define _XTAL_FREQ  4000000
#define TX  RA0
#define RX  RA1

void sendChar(char data){
    TX=0;
    __delay_us(100);
    for(int i=0;i<8;i++){
        TX=data&(1<<0);
        data>>=1;
        __delay_us(75);
    }
    TX=1;
    __delay_us(100);
}

char myChar=0,temp=0;
void receiveChar(void){
    if(RX==0){
        __delay_us(100);

        for(char i=0;i<8;i++){
            __delay_us(60);
            if(RX==1) myChar|=(1<<i);
            else myChar&=~(1<<i);
        }
        __delay_us(100);
    }
}

void sendText(char *text){
    while(*text) sendChar(*text++);
}

void softUARTInit(void){
    PORTA=0x00;
    TRISA=0x02;
    PORTB=0;
    TRISB=0;
    TX=1;
}

void main(){

    softUARTInit();
    sendText("PIC16F84A Software UART Read EEPROM Write And Read\r\n");
    for(uint8_t i=0;i<43;i++) {EEPROM_WRITE(i,i+48);while(WR==1);}
    for(uint8_t i=0;i<43;i++) {sendChar(EEPROM_READ(i)); while(RD==1);}
    sendText("\r\n");
    while(1){

    }
}
